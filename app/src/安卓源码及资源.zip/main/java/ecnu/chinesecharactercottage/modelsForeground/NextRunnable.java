package ecnu.chinesecharactercottage.modelsForeground;

/**
 * Created by 10040 on 2017/3/5.
 */

public abstract class NextRunnable{
    abstract public void next();
}
