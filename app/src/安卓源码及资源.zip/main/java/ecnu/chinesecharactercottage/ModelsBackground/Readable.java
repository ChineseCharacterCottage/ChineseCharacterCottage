package ecnu.chinesecharactercottage.ModelsBackground;

import android.content.Context;
import android.media.MediaPlayer;

/**
 * Created by Shensheng on 2016/9/30.
 * Readable
 */

public interface Readable {
    String getMediaKey();
}
